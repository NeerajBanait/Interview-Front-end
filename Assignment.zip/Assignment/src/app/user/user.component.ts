import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  

  constructor(private http:HttpClient ) {
   }
  
  user:any;
  remove:any;


  
  ngOnInit(): void {


        let resp= this.http.get('http://3-upstesting.site/machine_test/index.php/web_api/Users/Register');
    resp.subscribe((data) => this.user=data);

    console.log(this.user);

    let test= this.http.get('http://3-upstesting.site/machine_test/index.php/web_api/Users/remove_user');
    test.subscribe((data) => this.remove=data);

    let reg= this.http.get('http://3-upstesting.site/machine_test/index.php/web_api/Users/Register');
    reg.subscribe((data) => this.user=data);

    let user= this.http.get('http://3-upstesting.site/machine_test/index.php/web_api/Users/user_detail?user_id=1');
    user.subscribe((data) => this.user=data);
  }


//------------------Remove User-------------------------------//

  deleteRow(id:any){
    for(let i = 0; i < this.remove.length; ++i){
        if (this.remove[i].id === id) {
            this.remove.splice(i,1);
        }
    }
}

//---------------------update user-------------------------------//

data:any;
httpClient: any;
url: any;


public updatePost(postData: Object) {
  let endPoints = "/posts/1"
  this.httpClient.put(this.url + endPoints, postData).subscribe((data: any) => {
    console.log(data);
  });
}
  
}
