import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  

@Injectable({
  providedIn: 'root'
})

export class ApiService {


  constructor(private httpClient: HttpClient) { }

  private url = 'http://3-upstesting.site/machine_test/index.php/web_api/Users/Register';

getCats() {
   return this.httpClient.get(this.url); 
  } 
}